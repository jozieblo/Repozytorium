--Tworzenie pustej tabeli "Klient" :
--Z "INTA" zostały zdjęte ograniczenia co do liczby znaków, gdyż powodowało to ostrzeżenia.
 DROP TABLE  IF EXISTS Klient;
 CREATE TABLE Klient ( `id_klient` INT NOT NULL AUTO_INCREMENT , `Imie` VARCHAR(30) CHARACTER SET UTF8MB4 COLLATE utf8mb4_polish_ci NOT NULL , `Nazwisko` VARCHAR(40) CHARACTER SET UTF8MB4 COLLATE utf8mb4_polish_ci NOT NULL , `Data_urodzenia` DATE NOT NULL , `Ulica` VARCHAR(40) CHARACTER SET UTF8MB4 COLLATE utf8mb4_polish_ci NOT NULL , `Nr_domu` VARCHAR(10) NOT NULL , `Nr_Lokalu` INT NOT NULL , `Kod_pocztowy` VARCHAR(6) NOT NULL , `Miejscowosc` VARCHAR(45) CHARACTER SET UTF8MB4 COLLATE utf8mb4_polish_ci NOT NULL , `Email` VARCHAR(45) NOT NULL , `Telefon` INT NOT NULL , PRIMARY KEY (`id_klient`));

 --Wypełnianie tabeli "Klient" : (komendy podałem osobno bo bardziej czytelnie jest)

 INSERT INTO klient (`id_klient`, `Imie`, `Nazwisko`, `Data_urodzenia`, `Ulica`, `Nr_domu`, `Nr_Lokalu`, `Kod_pocztowy`, `Miejscowosc`, `Email`, `Telefon`) VALUES ('1', 'Jan', 'Kowalski', '1975-09-01', 'Pokątna', '52', '5', '11-330', 'Gdańsk', 'jan.kowalski@gmail.com', '876463281');


 INSERT INTO klient (`id_klient`, `Imie`, `Nazwisko`, `Data_urodzenia`, `Ulica`, `Nr_domu`, `Nr_Lokalu`, `Kod_pocztowy`, `Miejscowosc`, `Email`, `Telefon`) VALUES ('2', 'Piotr', 'Nowak', '1980-12-06', 'Kaszmirowa', '11', '2', '12-300', 'Warszawa', 'piotr.nowak@gmail.com', '657483291');

 INSERT INTO klient (`id_klient`, `Imie`, `Nazwisko`, `Data_urodzenia`, `Ulica`, `Nr_domu`, `Nr_Lokalu`, `Kod_pocztowy`, `Miejscowosc`, `Email`, `Telefon`) VALUES ('3', 'Dawid', 'Gawroński', '1999-12-06', 'Słoneczna', '7', '9', '10-000', 'Poznań', 'dawid.gaw@wp.pl', '748920101');

 INSERT INTO klient (`id_klient`, `Imie`, `Nazwisko`, `Data_urodzenia`, `Ulica`, `Nr_domu`, `Nr_Lokalu`, `Kod_pocztowy`, `Miejscowosc`, `Email`, `Telefon`) VALUES ('4', 'Damian', 'Ziaja', '1990-02-18', 'Tęczowa', '10', '9', '15-330', 'Kraków', 'dam.ziaj@wp.pl', '748593104');

 INSERT INTO klient (`id_klient`, `Imie`, `Nazwisko`, `Data_urodzenia`, `Ulica`, `Nr_domu`, `Nr_Lokalu`, `Kod_pocztowy`, `Miejscowosc`, `Email`, `Telefon`) VALUES ('5', 'Aleksander', 'Karecki', '1998-12-17', 'Majętna', '10', '3', '16-660', 'Białystok', 'alek.kar@gmail.com', '648394921');

 INSERT INTO klient (`id_klient`, `Imie`, `Nazwisko`, `Data_urodzenia`, `Ulica`, `Nr_domu`, `Nr_Lokalu`, `Kod_pocztowy`, `Miejscowosc`, `Email`, `Telefon`) VALUES ('6', 'Władysław', 'Kania', '1986-12-21', 'Agrestowa', '50', '8', '15-330', 'Kraków', 'wlad.kania@o2.pl', '854923842');

 INSERT INTO klient (`id_klient`, `Imie`, `Nazwisko`, `Data_urodzenia`, `Ulica`, `Nr_domu`, `Nr_Lokalu`, `Kod_pocztowy`, `Miejscowosc`, `Email`, `Telefon`) VALUES ('7', 'Karolina', 'Mika', '2000-12-23', 'Mickiewicza', '84C', '5', '18-880', 'Wrocław', 'karolina.mika@wp.pl', '834290901');

 INSERT INTO klient (`id_klient`, `Imie`, `Nazwisko`, `Data_urodzenia`, `Ulica`, `Nr_domu`, `Nr_Lokalu`, `Kod_pocztowy`, `Miejscowosc`, `Email`, `Telefon`) VALUES ('8', 'Dominika', 'Niekonieczna', '1999-12-29', 'Azbestowa', '5T', '1', '19-900', 'Kielce', 'domik.koniecz@onet.pl', '834984109');

INSERT INTO klient (`id_klient`, `Imie`, `Nazwisko`, `Data_urodzenia`, `Ulica`, `Nr_domu`, `Nr_Lokalu`, `Kod_pocztowy`, `Miejscowosc`, `Email`, `Telefon`) VALUES ('9', 'Krzysztof', 'Zalewski', '2001-04-06', 'Belwederska', '90U', '7', '13-330', 'Opole', 'krzysztof.zal@wp.pl', '874654732');

INSERT INTO klient (`id_klient`, `Imie`, `Nazwisko`, `Data_urodzenia`, `Ulica`, `Nr_domu`, `Nr_Lokalu`, `Kod_pocztowy`, `Miejscowosc`, `Email`, `Telefon`) VALUES ('10', 'Norbert', 'Gierczak', '1994-01-02', 'Diamentowa', '65V', '8', '14-330', 'Małdyty', 'nor.gier@wp.pl', '764632974');

 INSERT INTO klient (`id_klient`, `Imie`, `Nazwisko`, `Data_urodzenia`, `Ulica`, `Nr_domu`, `Nr_Lokalu`, `Kod_pocztowy`, `Miejscowosc`, `Email`, `Telefon`) VALUES ('11', 'Paweł', 'Nowicki', '1996-05-06', 'Cytrynowa', '2', '3', '18-430', 'Zakopane', 'pawel.nowicki@onet.pl', '640021983');

INSERT INTO klient (`id_klient`, `Imie`, `Nazwisko`, `Data_urodzenia`, `Ulica`, `Nr_domu`, `Nr_Lokalu`, `Kod_pocztowy`, `Miejscowosc`, `Email`, `Telefon`) VALUES ('12', 'Marta', 'Cokaj', '2001-09-10', 'Sezamowa', '32', '7', '14-300', 'Morąg', 'marta.cokaj@gmail.com', '748029465');


--Tworzenie pustej tabeli "Mebel" :

 DROP TABLE  IF EXISTS Mebel;
CREATE TABLE Mebel ( `id_mebel` INT NOT NULL AUTO_INCREMENT , `Rodzaj` VARCHAR(35) CHARACTER SET UTF8MB4 COLLATE utf8mb4_polish_ci NOT NULL , `Wysokosc` INT NOT NULL , `Glebokosc` INT NOT NULL , `Szerokosc` INT NOT NULL , `Waga` INT NOT NULL , `Cena_PLN` INT NOT NULL , `Odcien` VARCHAR(35) CHARACTER SET UTF8MB4 COLLATE utf8mb4_polish_ci NOT NULL , `id_Producent` INT NOT NULL , PRIMARY KEY (`id_mebel`));

ALTER TABLE mebel CHANGE `id_Producent` `id_Producenta` INT NOT NULL;

-- Wypełnianie tabeli "Mebel" :

INSERT INTO mebel (`id_mebel`, `Rodzaj`, `Wysokosc`, `Glebokosc`, `Szerokosc`, `Waga`, `Cena_PLN`, `Odcien`, `id_Producenta`) VALUES ('1', 'Szafa', '198', '58', '100', '87', '1411', 'Jasny dąb', '4');

INSERT INTO mebel (`id_mebel`, `Rodzaj`, `Wysokosc`, `Glebokosc`, `Szerokosc`, `Waga`, `Cena_PLN`, `Odcien`, `id_Producenta`) VALUES ('2', 'Sofa', '240', '66', '107', '100', '999', 'Wiśnia', '5');

INSERT INTO mebel (`id_mebel`, `Rodzaj`, `Wysokosc`, `Glebokosc`, `Szerokosc`, `Waga`, `Cena_PLN`, `Odcien`, `id_Producenta`) VALUES ('3', 'Narożnik', '300', '77', '201', '150', '1200', 'Szary', '1');

INSERT INTO mebel (`id_mebel`, `Rodzaj`, `Wysokosc`, `Glebokosc`, `Szerokosc`, `Waga`, `Cena_PLN`, `Odcien`, `id_Producenta`) VALUES ('4', 'Krzesło', '90', '49', '78', '15', '345', 'Kasztanowy', '2');

INSERT INTO mebel (`id_mebel`, `Rodzaj`, `Wysokosc`, `Glebokosc`, `Szerokosc`, `Waga`, `Cena_PLN`, `Odcien`, `id_Producenta`) VALUES ('5', 'Biurko', '200', '56', '67', '20', '300', 'Biały', '6');

INSERT INTO mebel (`id_mebel`, `Rodzaj`, `Wysokosc`, `Glebokosc`, `Szerokosc`, `Waga`, `Cena_PLN`, `Odcien`, `id_Producenta`) VALUES ('6', 'Fotel', '140', '45', '98', '20', '200', 'Czereśnia', '8');

INSERT INTO mebel (`id_mebel`, `Rodzaj`, `Wysokosc`, `Glebokosc`, `Szerokosc`, `Waga`, `Cena_PLN`, `Odcien`, `id_Producenta`) VALUES ('7', 'Stół', '120', '91', '47', '50', '400', 'Ciemny brąz', '10');

INSERT INTO mebel (`id_mebel`, `Rodzaj`, `Wysokosc`, `Glebokosc`, `Szerokosc`, `Waga`, `Cena_PLN`, `Odcien`, `id_Producenta`) VALUES ('8', 'Szafka nocna', '83', '87', '10', '100', '1411', 'Jasny brąz', '12');

INSERT INTO mebel (`id_mebel`, `Rodzaj`, `Wysokosc`, `Glebokosc`, `Szerokosc`, `Waga`, `Cena_PLN`, `Odcien`, `id_Producenta`) VALUES ('9', 'Regał', '201', '65', '102', '15', '250', 'Biały dąb', '11');

INSERT INTO mebel (`id_mebel`, `Rodzaj`, `Wysokosc`, `Glebokosc`, `Szerokosc`, `Waga`, `Cena_PLN`, `Odcien`, `id_Producenta`) VALUES ('10', 'Komoda', '120', '90', '56', '29', '350', 'Turkus', '9');

INSERT INTO mebel (`id_mebel`, `Rodzaj`, `Wysokosc`, `Glebokosc`, `Szerokosc`, `Waga`, `Cena_PLN`, `Odcien`, `id_Producenta`) VALUES ('11', 'Narożnik', '255', '34', '77', '101', '4000', 'Czarny', '7');

INSERT INTO mebel (`id_mebel`, `Rodzaj`, `Wysokosc`, `Glebokosc`, `Szerokosc`, `Waga`, `Cena_PLN`, `Odcien`, `id_Producenta`) VALUES ('12', 'Biurko', '99', '98', '80', '30', '340', 'Ciemny kryształ', '3');


--Tworzenie pustej tabeli "Zamówienie" :
 DROP TABLE  IF EXISTS Zamówienie;
CREATE TABLE Zamówienie ( `id_zamówienie` INT NOT NULL AUTO_INCREMENT , `Data_zlozenia_zamowienia` DATE NOT NULL , `Data_wysylki` DATE NOT NULL , `Koszt_PLN` INT NOT NULL , `id_Klient` INT NOT NULL , `id_Mebel` INT NOT NULL , `id_Dostawca` INT NOT NULL , PRIMARY KEY (`id_zamówienie`));

ALTER TABLE zamówienie CHANGE `id_Klient` `id_Klienta` INT NOT NULL;
ALTER TABLE `zamówienie` CHANGE `id_Mebel` `id_Mebla` INT NOT NULL;

-- Wypełnianie tabeli "Zamowienie" :

INSERT INTO zamówienie (`id_zamówienie`, `Data_zlozenia_zamowienia`, `Data_wysylki`, `Koszt_PLN`, `id_Klienta`, `id_Mebla`, `id_Dostawca`) VALUES ('1', '2020-08-22', '2020-08-16', '50', '2', '2', '12');


INSERT INTO zamówienie (`id_zamówienie`, `Data_zlozenia_zamowienia`, `Data_wysylki`, `Koszt_PLN`, `id_Klienta`, `id_Mebla`, `id_Dostawca`) VALUES ('2', '2020-03-11', '2020-03-16', '100', '1', '3', '11');


INSERT INTO zamówienie (`id_zamówienie`, `Data_zlozenia_zamowienia`, `Data_wysylki`, `Koszt_PLN`, `id_Klienta`, `id_Mebla`, `id_Dostawca`) VALUES ('3', '2020-08-15', '2020-08-20', '30', '3', '1', '10');


INSERT INTO zamówienie (`id_zamówienie`, `Data_zlozenia_zamowienia`, `Data_wysylki`, `Koszt_PLN`, `id_Klienta`, `id_Mebla`, `id_Dostawca`) VALUES ('4', '2020-06-02', '2020-06-16', '75', '4', '5', '9');


INSERT INTO zamówienie (`id_zamówienie`, `Data_zlozenia_zamowienia`, `Data_wysylki`, `Koszt_PLN`, `id_Klienta`, `id_Mebla`, `id_Dostawca`) VALUES ('5', '2020-02-02', '2020-02-10', '220', '10', '4', '8');


INSERT INTO zamówienie (`id_zamówienie`, `Data_zlozenia_zamowienia`, `Data_wysylki`, `Koszt_PLN`, `id_Klienta`, `id_Mebla`, `id_Dostawca`) VALUES ('6', '2020-11-02', '2020-11-05', '140', '12', '7', '7');


INSERT INTO zamówienie (`id_zamówienie`, `Data_zlozenia_zamowienia`, `Data_wysylki`, `Koszt_PLN`, `id_Klienta`, `id_Mebla`, `id_Dostawca`) VALUES ('7', '2020-12-02', '2020-12-04', '38', '11', '6', '6');


INSERT INTO zamówienie (`id_zamówienie`, `Data_zlozenia_zamowienia`, `Data_wysylki`, `Koszt_PLN`, `id_Klienta`, `id_Mebla`, `id_Dostawca`) VALUES ('8', '2020-01-02', '2020-01-06', '70', '9', '9', '5');


INSERT INTO zamówienie (`id_zamówienie`, `Data_zlozenia_zamowienia`, `Data_wysylki`, `Koszt_PLN`, `id_Klienta`, `id_Mebla`, `id_Dostawca`) VALUES ('9', '2020-05-02', '2020-05-10', '75', '8', '8', '4');


INSERT INTO zamówienie (`id_zamówienie`, `Data_zlozenia_zamowienia`, `Data_wysylki`, `Koszt_PLN`, `id_Klienta`, `id_Mebla`, `id_Dostawca`) VALUES ('10', '2020-04-02', '2020-04-06', '96', '7', '11', '3');


INSERT INTO zamówienie (`id_zamówienie`, `Data_zlozenia_zamowienia`, `Data_wysylki`, `Koszt_PLN`, `id_Klienta`, `id_Mebla`, `id_Dostawca`) VALUES ('11', '2020-07-02', '2020-07-07', '90', '6', '10', '2');


INSERT INTO zamówienie (`id_zamówienie`, `Data_zlozenia_zamowienia`, `Data_wysylki`, `Koszt_PLN`, `id_Klienta`, `id_Mebla`, `id_Dostawca`) VALUES ('12', '2020-09-02', '2020-09-11', '55', '5', '12', '1');

--Tworzenie pustej tabeli "Producent" :

 DROP TABLE  IF EXISTS Producent;
CREATE TABLE Producent ( `id_Producent` INT NOT NULL AUTO_INCREMENT , `Nazwa` VARCHAR(35) CHARACTER SET UTF8MB4 COLLATE utf8mb4_polish_ci NOT NULL , `Forma_prawna` VARCHAR(50) CHARACTER SET UTF8MB4 COLLATE utf8mb4_polish_ci NOT NULL , `Data_zalozenia` DATE NOT NULL , `Siedziba` VARCHAR(35) CHARACTER SET UTF8MB4 COLLATE utf8mb4_polish_ci NOT NULL , `Telefon` VARCHAR(9) NOT NULL , `email` VARCHAR(35) NOT NULL , PRIMARY KEY (`id_Producent`));

-- Wypełnianie tabeli "Producent" :


INSERT INTO producent (`id_Producent`, `Nazwa`, `Forma_prawna`, `Data_zalozenia`, `Siedziba`, `Telefon`, `email`) VALUES ('1', 'Bewelik', 'Spółka akcyjna', '2001-12-20', 'Warszawa', '759483210', 'bewelik@wp.pl');

INSERT INTO producent (`id_Producent`, `Nazwa`, `Forma_prawna`, `Data_zalozenia`, `Siedziba`, `Telefon`, `email`) VALUES ('2', 'PolMebl', 'Spółka jawna', '2003-11-18', 'Gdańsk', '950694832', 'polm@wp.pl');

INSERT INTO producent (`id_Producent`, `Nazwa`, `Forma_prawna`, `Data_zalozenia`, `Siedziba`, `Telefon`, `email`) VALUES ('3', 'Hadlub', 'Spółka z ograniczoną odpowiedzialnością', '2000-08-19', 'Toruń', '984758210', 'hadlub@wp.pl');

INSERT INTO producent (`id_Producent`, `Nazwa`, `Forma_prawna`, `Data_zalozenia`, `Siedziba`, `Telefon`, `email`) VALUES ('4', 'Mopr Technology', 'Spółka cywilna', '1999-06-15', 'Malbork', '203957100', 'mopr@wp.pl');

INSERT INTO producent (`id_Producent`, `Nazwa`, `Forma_prawna`, `Data_zalozenia`, `Siedziba`, `Telefon`, `email`) VALUES ('5', 'Noc Turne', 'Spółka partnerska', '1998-01-29', 'Frombork', '700948231', 'nocturn@wp.pl');

INSERT INTO producent (`id_Producent`, `Nazwa`, `Forma_prawna`, `Data_zalozenia`, `Siedziba`, `Telefon`, `email`) VALUES ('6', 'Flame Corporation', 'Spółka niejawna', '2005-10-30', 'Szczecin', '945093846', 'flame@wp.pl');

INSERT INTO producent (`id_Producent`, `Nazwa`, `Forma_prawna`, `Data_zalozenia`, `Siedziba`, `Telefon`, `email`) VALUES ('7', 'Ver Sus', 'Spółka jawna', '2007-09-28','Kraków', '657390200', 'vars@wp.pl');

INSERT INTO producent (`id_Producent`, `Nazwa`, `Forma_prawna`, `Data_zalozenia`, `Siedziba`, `Telefon`, `email`) VALUES ('8', 'Daze Corp', 'Spółka cywilna', '2010-05-12', 'Zakopane', '200938475', 'daze@wp.pl');

INSERT INTO producent (`id_Producent`, `Nazwa`, `Forma_prawna`, `Data_zalozenia`, `Siedziba`, `Telefon`, `email`) VALUES ('9', 'Plow Rane', 'Spółka z ograniczoną odpowiedzialnością', '1990-04-11', 'Gorzów', '109485285', 'plowk@wp.pl');

INSERT INTO producent (`id_Producent`, `Nazwa`, `Forma_prawna`, `Data_zalozenia`, `Siedziba`, `Telefon`, `email`) VALUES ('10', 'Hune Jaws', 'Spółka niejawna', '1980-02-05', 'Morąg', '984759209', 'hune@wp.pl');

INSERT INTO producent (`id_Producent`, `Nazwa`, `Forma_prawna`, `Data_zalozenia`, `Siedziba`, `Telefon`, `email`) VALUES ('11', 'Antony', 'Spółka cywilna', '2002-03-02', 'Olsztyn', '850493872', 'antony@wp.pl');

INSERT INTO producent (`id_Producent`, `Nazwa`, `Forma_prawna`, `Data_zalozenia`, `Siedziba`, `Telefon`, `email`) VALUES ('12', 'WLM', 'Spółka partnerska', '2003-12-03', 'Mikołajki', '874902935', 'wlm@wp.pl');

--Tworzenie pustej tabeli "Dostawca" :

 DROP TABLE  IF EXISTS Dostawca;
CREATE TABLE Dostawca ( `id_Dostawcy` INT NOT NULL AUTO_INCREMENT , `Firma` VARCHAR(35) CHARACTER SET UTF8MB4 COLLATE utf8mb4_polish_ci NOT NULL , `Siedziba` VARCHAR(35) CHARACTER SET UTF8MB4 COLLATE utf8mb4_polish_ci NOT NULL , `Wlasciciel` VARCHAR(35) CHARACTER SET UTF8MB4 COLLATE utf8mb4_polish_ci NOT NULL , `Data_zalozenia` DATE NOT NULL , `Liczba_pracownikow` INT NOT NULL , PRIMARY KEY (`id_Dostawcy`));
 -- Wypełnianie tabeli "Dostawca" :


INSERT INTO dostawca (`id_Dostawcy`, `Firma`, `Siedziba`, `Wlasciciel`, `Data_zalozenia`, `Liczba_pracownikow`) VALUES ('1', 'DPD', 'Paryż', 'Jean Reno', '2000-12-08', '205000');


INSERT INTO dostawca (`id_Dostawcy`, `Firma`, `Siedziba`, `Wlasciciel`, `Data_zalozenia`, `Liczba_pracownikow`) VALUES ('2', 'FeedEx', 'Los Angeles', 'James Marley', '1990-11-08', '100000');


INSERT INTO dostawca (`id_Dostawcy`, `Firma`, `Siedziba`, `Wlasciciel`, `Data_zalozenia`, `Liczba_pracownikow`) VALUES ('3', 'UPS', 'Barcelona', 'Bob Carrson', '1998-10-08', '600100');


INSERT INTO dostawca (`id_Dostawcy`, `Firma`, `Siedziba`, `Wlasciciel`, `Data_zalozenia`, `Liczba_pracownikow`) VALUES ('4', 'Throw', 'Berlin', 'Frank Mayer', '1970-09-08', '304500');


INSERT INTO dostawca (`id_Dostawcy`, `Firma`, `Siedziba`, `Wlasciciel`, `Data_zalozenia`, `Liczba_pracownikow`) VALUES ('5', 'SaneB', 'Warszawa', 'Teressa Scott', '2001-06-08', '300000');


INSERT INTO dostawca (`id_Dostawcy`, `Firma`, `Siedziba`, `Wlasciciel`, `Data_zalozenia`, `Liczba_pracownikow`) VALUES ('6', 'InPost', 'Kraków', 'Zdobysław Kawałek', '2002-04-07', '300870');


INSERT INTO dostawca (`id_Dostawcy`, `Firma`, `Siedziba`, `Wlasciciel`, `Data_zalozenia`, `Liczba_pracownikow`) VALUES ('7', 'DrakeP', 'Gdynia', 'Karol Krawczyk', '2003-03-06', '500000');


INSERT INTO dostawca (`id_Dostawcy`, `Firma`, `Siedziba`, `Wlasciciel`, `Data_zalozenia`, `Liczba_pracownikow`) VALUES ('8', 'KoGT', 'Moskwa', 'Wladimir Putin', '2004-02-05', '210000');


INSERT INTO dostawca (`id_Dostawcy`, `Firma`, `Siedziba`, `Wlasciciel`, `Data_zalozenia`, `Liczba_pracownikow`) VALUES ('9', 'SBM', 'Zagrzeb', 'Hern Ferster', '2005-08-03', '900000');


INSERT INTO dostawca (`id_Dostawcy`, `Firma`, `Siedziba`, `Wlasciciel`, `Data_zalozenia`, `Liczba_pracownikow`) VALUES ('10', 'BSDM', 'Oslo', 'Jean Moo', '2006-08-02', '330000');


INSERT INTO dostawca (`id_Dostawcy`, `Firma`, `Siedziba`, `Wlasciciel`, `Data_zalozenia`, `Liczba_pracownikow`) VALUES ('11', 'PolHuP', 'Frankfurt', 'Puard Moin', '2010-04-01', '380000');


INSERT INTO dostawca (`id_Dostawcy`, `Firma`, `Siedziba`, `Wlasciciel`, `Data_zalozenia`, `Liczba_pracownikow`) VALUES ('12', 'FeedMe', 'Wiedeń', 'Akeb Porr', '1999-05-12', '120000');


-- Dodawanie  indeksów w celu stworzenia związków między tabelami: 

ALTER TABLE mebel ADD INDEX( `id_Producenta`); 

ALTER TABLE zamówienie ADD INDEX( `id_Klienta`, `id_Mebla`, `id_Dostawca`);


-- Zapytania+widoki:
-- 1. 
DROP VIEW IF EXISTS widok1;
CREATE VIEW widok1 AS SELECT * FROM Klient;

SELECT * FROM widok1 ORDER BY Id_klient ASC;

-- 2.
DROP VIEW IF EXISTS widok2;
CREATE VIEW widok2 AS SELECT Id_klient,Imie,Nazwisko,Ulica FROM Klient WHERE Ulica="pokątna";

SELECT * FROM widok2 ORDER BY Id_klient DESC;

-- 3.
DROP VIEW IF EXISTS widok3;
CREATE VIEW widok3 AS SELECT * FROM dostawca WHERE Liczba_pracownikow>500000;

SELECT * FROM widok3 ORDER BY id_Dostawcy DESC;
-- 4.
DROP VIEW IF EXISTS widok4;
CREATE VIEW widok4 AS SELECT * FROM zamówienie WHERE (MONTH(Data_zlozenia_zamowienia) BETWEEN 3 AND 15) AND (DAY(Data_zlozenia_zamowienia) BETWEEN 5 AND 15);

SELECT * FROM widok4;

-- 5.
DROP VIEW IF EXISTS widok5;
CREATE VIEW widok5 AS SELECT * FROM mebel WHERE (szerokosc BETWEEN 100 AND 200) AND rodzaj="Sofa";

SELECT * FROM widok5 ORDER BY id_mebel ASC;

-- 6. Łącznie wewnętrzne
DROP VIEW IF EXISTS widok6;

CREATE VIEW widok6 AS (SELECT id_klient, Imie, Nazwisko,Data_urodzenia, Telefon,id_zamówienie, Koszt_PLN, id_Klienta, id_mebla FROM klient INNER JOIN zamówienie ON klient.id_klient = zamówienie.id_Klienta);

SELECT * FROM widok6 ORDER BY id_klient DESC;

-- 7. Łączenie lewostronne

DROP VIEW IF EXISTS widok7;

CREATE VIEW widok7 AS SELECT id_mebel, rodzaj, waga, Cena_PLN,id_Producent, Nazwa, Siedziba,email FROM mebel LEFT JOIN producent ON mebel.id_Producenta = producent.id_Producent WHERE rodzaj="narożnik";

SELECT * FROM widok7 ORDER BY id_mebel ASC;
-- 8. Łączenie prawostronne
DROP VIEW IF EXISTS widok8;

CREATE VIEW widok8 AS SELECT id_Dostawcy, Firma, Siedziba, Wlasciciel,id_zamówienie,Data_zlozenia_zamowienia,Data_wysylki,Koszt_PLN,id_Mebla,id_Dostawca FROM zamówienie RIGHT JOIN Dostawca ON dostawca.id_Dostawcy= zamówienie.id_Dostawca WHERE Koszt_PLN=75;

SELECT * FROM widok8 ORDER BY id_Dostawcy ASC;

--9.Podzapytanie
DROP VIEW IF EXISTS widok9;

CREATE VIEW widok9 AS SELECT DISTINCT id_klient, Imie,Nazwisko,Data_urodzenia,Ulica FROM klient,zamówienie WHERE id_klient=(SELECT id_klienta FROM zamówienie WHERE id_zamówienie=10);

SELECT * FROM widok9;

--10. Funkcje agregujące
DROP VIEW IF EXISTS widok10;

CREATE VIEW widok10 AS SELECT SUM(Cena_PLN) AS "Suma_wartości mebli z wybranego przedzialu" FROM mebel WHERE id_mebel BETWEEN 1 AND 5;
SELECT * FROM widok10;

--11.
DROP VIEW IF EXISTS widok11;
CREATE VIEW widok11 AS SELECT id_klient,Imie,Nazwisko, AVG(Koszt_PLN) AS "Średni koszt zamówień" FROM zamówienie INNER JOIN klient ON zamówienie.id_klienta = klient.id_klient WHERE id_klient=8;
SELECT * FROM widok11;

--12.
DROP VIEW IF EXISTS widok12;
CREATE VIEW widok12 AS SELECT MIN(Liczba_pracownikow) AS "Najmniejsza liczba pracownikow" FROM dostawca;

SELECT * FROM widok12;

--13.
DROP VIEW IF EXISTS widok13;
CREATE VIEW widok13 AS SELECT id_mebel,Rodzaj, MAX(Szerokosc) AS "Najszerszy mebel" FROM mebel INNER JOIN producent ON mebel.id_producenta=producent.id_producent WHERE id_producenta BETWEEN 1 AND 5;
SELECT * FROM widok13;


--14.
DROP VIEW IF EXISTS widok14;
CREATE VIEW widok14 AS SELECT COUNT(*) AS "Liczba rekordow" FROM klient WHERE imie="Jan";

SELECT * FROM widok14;


--1.Wyzwalacze:

--Odejmuje 50 PLN od każdego wcześniej wcześniej dodanego mebla za każdego nowego klienta, który został zarejestrowany, w ramach promocji.
DROP TRIGGER  IF EXISTS wyzwalacz1;
CREATE TRIGGER wyzwalacz1
BEFORE INSERT ON klient
FOR EACH ROW
UPDATE mebel SET Cena_PLN=Cena_PLN-50 WHERE id_mebel<=12;


--Wprowadza dane usunietego mebla,inkrementując id, po usuniecie danego rekordu.
DELIMITER $$
DROP TRIGGER  IF EXISTS wyzwalacz2;
CREATE TRIGGER wyzwalacz2 AFTER DELETE ON mebel
FOR EACH ROW
INSERT INTO Wycofane_meble VALUES ( old.id_mebel+1,old.rodzaj,old.wysokosc,old.glebokosc,old.szerokosc,old.waga,
old.Cena_PLN,old.Odcien,old.id_Producenta);
END $$;
DELIMITER ;



--2.Funkcja:
--Prosta funkcja dodajaca do siebie 2 liczby
DROP FUNCTION  IF EXISTS funkcja1;
CREATE FUNCTION funkcja1(liczba1 INT, liczba2 INT)
RETURNS INT deterministic
RETURN (liczba1-liczba2);
SELECT funkcja1(20,5);


--3.Procedura operuje na stworzonej tabli pomocnicza, dodając 2 rekordy i wybierając dane z tabeli dostawcy na podstawie połączenie między id dostawcy a id tabeli pomocniczej.

DROP PROCEDURE IF EXISTS procedura;
DELIMITER $$
CREATE PROCEDURE sklep_meblowy.procedura (IN id INT , IN imie VARCHAR(30))
BEGIN
INSERT INTO pomocnicza(id_pomoc, imie) VALUE (id,imie);
SELECT dostawca.id_dostawcy, dostawca.Firma, dostawca.Siedziba, dostawca.Wlasciciel, pomocnicza.imie,pomocnicza.id_pomoc FROM dostawca INNER JOIN pomocnicza ON dostawca.id_Dostawcy=pomocnicza.id_pomoc WHERE dostawca.id_dostawcy=id;
END$$
DELIMITER ;
CALL procedura('7','Piotrek');



